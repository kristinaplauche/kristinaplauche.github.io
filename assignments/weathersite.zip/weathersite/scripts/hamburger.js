function toggleNavMenu() {

    document.getElementById("primaryNav").classList.toggle("hide");
}